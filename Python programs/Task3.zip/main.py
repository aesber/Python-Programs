''' Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program calculates how many hours the workers did work during the weekdays and weekends and the amount of their pay.
'''

wkdayhours = float(input("Enter weekday hours: ")) # hours that workers worked during the weekdays
wkdaypay_rate = float(input("Enter weekday hourly pay rate: ")) # their hourly rate during weekday
wkendhours = float(input("Enter weekend hours: ")) # hours that workers worked during the weekends

print(f"\nPayment Details: \n")

# weekday pay

wkday_amount = wkdayhours * wkdaypay_rate # multiplies the weekdaypay by weekday pay rate
wkdaytotal = "Your total weekday pay is: " # sum of the weekday pay
print(f"{wkdaytotal}${wkday_amount:.2f}") #prints the results

# weekend pay

wkendpay_rate = 2 * wkdaypay_rate  # multplies twice the weekend pay amount as it is different from the weekdays pay
wkendpay_amount = wkendpay_rate * wkendhours
wkendtotal = "Your total weekend pay is: " #sum of the weekend pay
print(f"{wkendtotal}${wkendpay_amount:.2f}") # prints the results

# total pay amount of weekday pay + weekend pay

totalpay_wkend_wkday = wkday_amount + wkendpay_amount # adding the two pays together (weekend & weekday)
totalpay_amount = "Total pay amount is: " # prints the output of "Total amount"
print(f"{totalpay_amount:<27}${totalpay_wkend_wkday:.2f}") # prints the total amount of two pays adding together