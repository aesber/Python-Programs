'''
 Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program draw a pattern of circles.
'''

from turtle import *

# Read and invalidate number of circles
while True:
    cirnum = int(input("Enter a number (2-6 incl.): "))
    if cirnum >= 2 and cirnum <= 6:
        break
    else:
        print("Invalid")

x, y, r = 0, 0, 10
speed(0)

# draws the pink circle

for i in range(cirnum):  #horizontal, left to right
    #move pen to (x,y) without a line
    pu()
    goto(x, y)
    pd()

    begin_fill()
    fillcolor("pink")
    circle(r)
    end_fill()

    x += r * 2  #condition update x

# draws the red circle
  
for i in range(cirnum): # draws diagonally, top-right to bottom-left
  pu()
  goto(x, y)
  pd()

  begin_fill()
  fillcolor("red")
  circle(r)
  end_fill()

  x -= r * 2
  y -= r * 2

# draws the blue circle
  
for i in range(cirnum): # draws horizontally, bottom-left to top-left
  pu()
  goto(x, y)
  pd()

  begin_fill()
  fillcolor("blue")
  circle(r)
  end_fill()

  y += r * 2

# draws the square outline (black)

# pu, goto, pd = moves the pen to the right position before starting to draw the square.
pu()
goto(0, 0)
pd() 

# calculates the square using cirnum
square = cirnum * r * 2
pensize(2)
pencolor("black")

for i in range(4): # range = (4) sides of square
    fd(square) #forward
    rt(90) #right