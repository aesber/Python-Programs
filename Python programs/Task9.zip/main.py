''' Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program process a supermarket sale records.
'''

def read_data(filename):
  records = [] #empty list
  with open(filename) as fr: #open a textile and fr(fileread)
    lines = fr.readlines() #readlines = read all the file in data.txt
    for line in lines:
      str_rec = line.split(",") #line "Hm001,6,Frankton,42305.67"
      storeID = str_rec[0] #str_rec: ["Hm001","6","Frankton","42305.67"]
      employees = int(str_rec[1])
      suburb = str_rec[2]
      sale_volume = float(str_rec[3])
      rec = [storeID, employees, suburb, sale_volume]
      records.append(rec)
  return records

def print_all_records(records): #prints the records in list
  h1,h2,h3,h4 = "Store ID","Employees","Suburb","Sales"
  print(f"{h1:<15}{h2:<15}{h3:<18}{h4}")
  print("-" * 60)
  for rec in records:
    print(f"{rec[0]:<15}{rec[1]:<15}{rec[2]:<18}{rec[3]}")

def write_data(filename, records): #destination & the data
  with open(filename, "w") as fw:
    for rec in records:
      fw.write(f"{rec[0]},{rec[1]},{rec[2]},{rec[3]}")

def get_min_sale_record(records): #gives the suburb that has the minimum sale volume
  #data [0] the 1st record from the list
  #data [3] the 4th element of the 1st record (sales)
  min_sale = records[0][3]
  suburb = 0
  for rec in records:
    if rec[3] < min_sale:
      min_sale = rec[3]
      suburb = rec[2]
  return min_sale, suburb

def count_employees(records): #counts the employee that got 50k+ sales
  total_employees = 0
  for rec in records:
    if rec[3] > 50000:
     total_employees += rec[1]
  return total_employees

def query_suburb_stats(records): #calculates the branch that the users enters with total sale & average sale
  branchName = input("Enter branch name: ")
  total_sale = 0
  avg_sale = 0
  for rec in records:
    if branchName.lower() == rec[2].lower():
      total_sale += rec[3]
      avg_sale = total_sale/2
  if avg_sale == 0:
    print(f"No record was found for suburb {branchName}")
  else:
    print(f"Total sale by {branchName}: {total_sale}")
    print(f"Average sale by {branchName}: ${avg_sale}")

def main(): #puts all the other functions together, other functions will not work without this
  data = read_data("data.txt") #where the files is stored
  write_data("backup.txt", data)
  print_all_records(data)
  min_sale, suburb = get_min_sale_record(data)
  print(f"\nThe minimum sale volume is: ${min_sale:.2f}\n")
  print(f"The suburb with the minimum sale is: {suburb}\n")
  total_employees = count_employees(data)
  print(f"Total employees from stores with sales more than $50,000: {total_employees}\n")
  query_suburb_stats(data)
main()
