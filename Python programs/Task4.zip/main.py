''' Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program displays a different message for each day of the week. For example, 1-monday, 2-tuesday, 3-wednesday etc.
''' 

num_day_wk = int (input("Enter a number (1-7): ")) # users input a number (int = because its a number input) that coressponds for each day of the week (1-monday etc.)
if num_day_wk == 1:
  print("Monday again.") # if user input 1, it will out put as monday etc.
elif num_day_wk == 2:
  print("Tuesday, getting there!")
elif num_day_wk == 3:
  print("Wednesday, almost there!")
elif num_day_wk == 4:
  print("Thursday, don't give up!")
elif num_day_wk == 5:
  print("Friday, 2 more days!")
elif num_day_wk == 6:
  print("Relaxing Saturday")
elif num_day_wk == 7:
  print("Sunday, day off!")
else:
  print(f"Mysterious day") # if user enters anything other than 1-7 it will input as an error or mysterious day because it is not part of 1-7 inclusive days.
  