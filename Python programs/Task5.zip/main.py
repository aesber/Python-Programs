''' Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program determines if a supermarket customer is eligible to recieve discount.
'''

while True:
  price = float(input("Enter product price: $")) #float to read decimal input
  if price >= 1:
    break #stops the loop
  else:
    print("Invalid") #if user enter less than 0 of the price it will print invalid.
    
while True:
  quantity = int(input("Enter quantity: "))
  if quantity >= 1:
    break #stops the loop
  else:
    print("Invalid") #if user enter less than 0 (-1 etc.), it will print invalid.
  
while True:
  discount = input("Have you claimed the discount before (y/n): ").lower() #users enter y or n
  if discount == "y" or discount == "n":
    break #stops the loop
  else:
    print("Invalid. Please enter y or n.") #if user did not enter y/n or anything else, it will print invalid.

total = quantity * price #quanity multiple by the price
msg1 = "\nTotal shopping amount: $ " #\n adds space between the paragraphs
msg2 = "Claimed discount: "
print(f"{msg1:<20}{total:.1f}") #prints the total amount in 1dp
print(f"{msg2:<10}{discount}") #output the claimed discount

# processes if the user is eligible for discount or not based on the total shopping amount & if they have claimed discount before or not

# if n and less than $500 eligible for discount
if discount == "n" and total <=500:
  print("You are eligible!")
else: # if y or higher than $500+ not eligible for discount
  print("Sorry, you are not eligible.")