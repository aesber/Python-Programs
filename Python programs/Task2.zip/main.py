# Assignment Task 2

''' Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program reads the radius of a circle and calculates its perimeter and area.
''' 

import math

radius_circle = float(input("Enter radius: ")) # where users enters the radius of the circle

# calculates the area of the circle

square_radius = radius_circle * radius_circle # distance from where the center of the polygon(shape) to any of its vertices.
area_circle =  square_radius * math.pi 
print("Area: " , area_circle ) # prints the sum of the area of circle

# caculates the or perimeter of the circle

perim_circle = radius_circle * 2 * math.pi
print("Perimeter: " , perim_circle) # prints the sum of perimeter of the circle
