''' Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program displays a list of records.
'''

# Compose a list of film records.
film_list = []
film1 = ['FM01', 'Stealth', 135, 80]
film2 = ['FM02', 'Supernova', 90, 15]
film3 = ['FM03', 'Robin Hood', 100, 85]
film4 = ['FM04', 'Rollerball', 70, 26]
film5 = ['FM05', 'Rust', 85, 20]
film_list.append(film1)
film_list.append(film2)
film_list.append(film3)
film_list.append(film4)
film_list.append(film5)

# displays the film title with box-office, as well as the total film count as per sample output.

# Headings
ttl1, ttl2 = "Title", "Box-office\n"
print(f"{ttl1:<20}{ttl2:<20}")

#shows the data (film name[1] & box-office figure which is in million dollars[3])

for rec in film_list:
  print(f"{rec[1]:<20}{rec[3]:<20}")

print(f"\nFilm count: {len(film_list)}") #calculates the length of the list which is 5


