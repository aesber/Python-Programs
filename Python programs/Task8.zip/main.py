''' Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program process a list of records.
'''

def get_records():
 # Compose a list of film records. 
 film_list = []
 film_list.append(['FM01', 'Stealth', 135, 80])
 film_list.append(['FM02', 'Supernova', 90, 15])
 film_list.append(['FM03', 'Robin Hood', 100, 85])
 film_list.append(['FM04', 'Rollerball', 70, 26])
 film_list.append(['FM05', 'Rust', 85, 20])
 return film_list
  
def display_list(data): #defining a function definition
  h1, h2, h3, h4 = "ID", "Title", "Budget", "Box-office"
  print(f"{h1:<10}{h2:<20}{h3:<10}{h4}")
  print("-" * 50) #produce the dash line across the headings
  for rec in data:
    print(f"{rec[0]:<10}{rec[1]:<20}{rec[2]:<10}{rec[3]}")

def search_by_film_id(data): #user search for film
  film_id = input("\nEnter film id: ")
  film_found = None #flag variable to indicate a match
  
  for rec in data:
    if film_id.lower() == rec[0].lower():
      film_found = rec #updates the flag
      break
  if film_found == None:
    print(f"No matching film for {film_id}")
  else:
    print(f"\nFilm matching the given id: {film_found[1]}")
    print(f"Film budget loss: {rec[2]-rec[3]}") #calculates the film budget loss selected by the user

def get_total_budget_loss(data): #value return
  #return the calculated total budget of all films
  total = 0
  for rec in data:
    total += rec[2] - rec[3] #subtracting budget & box-office

  avg = 0
  if len(data) > 0:
    avg = total
  return avg

def main(): #outputs every code above on each def headings
  film_list = get_records()
  display_list(film_list)
  search_by_film_id(film_list)
  budget_loss = get_total_budget_loss(film_list)
  print(f"\nTotal buget loss of all films: {budget_loss}")
main() #main function call must be at the end for the codes to work above i