#Assignment  Task 1

''' Student: Allie Esber 21524438
Pledge of honour: I declare this is solely my own work.
Description: This program draws a letter E by using the turtle import.
''' 

from turtle import *

# to show the turtle that draws the lines
shape("turtle")
color("red")

# the color of the lines & size
pencolor("blue")
pensize(4) 

left(90) # the first line in E
fd(75)
right(100)
left(50)
right(40)
fd(50)

left(50) # going back to do another line in the middle
seth(180)
fd(50)
seth(270)
fd(37)
seth(0)
fd(50)

seth(180) # the last line in E
fd(50)
seth(270)
fd(38)
seth(0)
fd(50) 
